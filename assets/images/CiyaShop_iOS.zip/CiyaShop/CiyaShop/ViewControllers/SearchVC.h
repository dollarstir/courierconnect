//
//  SearchVC.h
//  QuickClick
//
//  Created by Kaushal PC on 05/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchVC : UIViewController

@property BOOL fromViewController;
@property BOOL fromMore;

@end
