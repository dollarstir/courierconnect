//
//  MyRewardVC.h
//  QuickClick
//
//  Created by Kaushal PC on 02/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyRewardVC : UIViewController
@property(strong,nonatomic) NSString *strComeFrom;
@end
