//
//  HomeVC.h
//  QuickClick
//
//  Created by Umesh on 4/15/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController


@end
