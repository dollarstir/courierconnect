//
//  ContactSellerVC.h
//  CiyaShop
//
//  Created by Kaushal PC on 08/11/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ViewController.h"

@interface ContactSellerVC : ViewController

@property NSString *strSellerID;

@end
