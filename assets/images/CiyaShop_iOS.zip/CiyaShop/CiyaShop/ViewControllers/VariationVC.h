//
//  VariationVC.h
//  CiyaShop
//
//  Created by Apple on 25/01/19.
//  Copyright © 2019 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VariationVC : UIViewController

@property Product *product;

@end

NS_ASSUME_NONNULL_END
