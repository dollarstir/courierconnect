//
//  WishListVC.h
//  QuickClick
//
//  Created by APPLE on 21/04/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WishListVC : UIViewController

@end
