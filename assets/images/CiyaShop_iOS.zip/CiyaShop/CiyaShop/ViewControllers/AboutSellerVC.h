//
//  AbouSellerVC.h
//  CiyaShop
//
//  Created by Kaushal PC on 03/11/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ViewController.h"

@interface AboutSellerVC : ViewController

@property NSString *strTitle;
@property NSString *strDesc;
@property NSString *strSellerID;

@end
