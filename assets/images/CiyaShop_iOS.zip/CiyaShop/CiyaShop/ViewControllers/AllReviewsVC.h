//
//  AllReviewsVC.h
//  CiyaShop
//
//  Created by Kaushal PC on 14/11/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ViewController.h"

@interface AllReviewsVC : ViewController

@property (strong, nonatomic) NSMutableArray *arrComments;
@property (strong, nonatomic) NSString *strTitle;

@property BOOL fromProductDetail;
@end
