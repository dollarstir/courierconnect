//
//  DescriptionVC.h
//  QuickClick
//
//  Created by Kaushal PC on 28/06/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DescriptionVC : UIViewController

@property NSString *strDescTitle;
@property NSString *strName;
@property NSString *strImage;
//@property NSAttributedString *strDesc;
@property NSString *strDesc;
@end
