//
//  MyPointsVC.h
//  CiyaShop
//
//  Created by potenza on 10/05/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPointsVC : UIViewController

@end
