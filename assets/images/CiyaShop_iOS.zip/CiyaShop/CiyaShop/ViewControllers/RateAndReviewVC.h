//
//  RateAndReviewVC.h
//  CiyaShop
//
//  Created by Kaushal PC on 16/04/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RateAndReviewVC : UIViewController

@property NSString *strProductUrl, *strName, *strID;

@end
