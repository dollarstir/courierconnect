//
//  HeaderTabCell.m
//  QuickClick
//
//  Created by Kaushal PC on 22/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "HeaderTabCell.h"

@implementation HeaderTabCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
