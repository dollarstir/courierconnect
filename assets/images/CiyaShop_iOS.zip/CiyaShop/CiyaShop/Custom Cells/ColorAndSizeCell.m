//
//  ColorAndSizeCell.m
//  QuickClick
//
//  Created by Kaushal PC on 19/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ColorAndSizeCell.h"

@implementation ColorAndSizeCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    // Initialization code
}

@end
