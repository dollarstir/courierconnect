//
//  ReasonToBuyCell.m
//  QuickClick
//
//  Created by Kaushal PC on 13/09/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ReasonToBuyCell.h"

@implementation ReasonToBuyCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
