//
//  AccountOptionCell.m
//  QuickClick
//
//  Created by Kaushal PC on 27/04/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "AccountOptionCell.h"

@implementation AccountOptionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
