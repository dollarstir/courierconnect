//
//  SubSearchCell.h
//  QuickClick
//
//  Created by Kaushal PC on 12/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubSearchCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblTitle;

@end
