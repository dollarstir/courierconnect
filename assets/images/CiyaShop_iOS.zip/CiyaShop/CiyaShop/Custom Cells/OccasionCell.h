//
//  OccasionCell.h
//  QuickClick
//
//  Created by Umesh on 5/31/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OccasionCell : UITableViewCell

@property IBOutlet UILabel *lblOccasionName;
@property IBOutlet UIImageView *imgSelectionImage;

@end
