//
//  HotOffersCell.m
//  QuickClick
//
//  Created by APPLE on 26/04/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "HotOffersCell.h"

@implementation HotOffersCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
