//
//  ShopNowCatagoryCell.m
//  QuickClick
//
//  Created by Kaushal PC on 10/08/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ShopNowCatagoryCell.h"

@implementation ShopNowCatagoryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
