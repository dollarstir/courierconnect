//
//  MyPointsCell.h
//  CiyaShop
//
//  Created by potenza on 11/05/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPointsCell : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *lblEvent;
@property(strong,nonatomic) IBOutlet UILabel *lblDate;
@property(strong,nonatomic) IBOutlet UILabel *lblPoint;
@property(strong,nonatomic) IBOutlet UILabel *lblLine;

@end
