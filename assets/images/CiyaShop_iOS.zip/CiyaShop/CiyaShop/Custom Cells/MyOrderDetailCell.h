//
//  MyOrderDetailCell.h
//  QuickClick
//
//  Created by Kaushal PC on 02/08/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyOrderDetailCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblRate;

@end
