//
//  ColorCell.m
//  QuickClick
//
//  Created by Kaushal PC on 22/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "ColorCell.h"

@implementation ColorCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
