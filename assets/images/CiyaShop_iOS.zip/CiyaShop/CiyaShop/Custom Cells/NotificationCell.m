//
//  NotificationCell.m
//  QuickClick
//
//  Created by Kaushal PC on 04/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "NotificationCell.h"

@implementation NotificationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
