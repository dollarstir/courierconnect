//
//  SocialCell.m
//  QuickClick
//
//  Created by Kaushal PC on 16/09/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "SocialCell.h"

@implementation SocialCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
