//
//  DownloadCell.m
//  CiyaShop
//
//  Created by Kaushal Parmar on 07/05/19.
//  Copyright © 2019 Potenza. All rights reserved.
//

#import "DownloadCell.h"

@implementation DownloadCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
