//
//  MyPointsCell.m
//  CiyaShop
//
//  Created by potenza on 11/05/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import "MyPointsCell.h"

@implementation MyPointsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
