//
//  BuyReasonCell.m
//  CiyaShop
//
//  Created by Kaushal PC on 04/10/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "BuyReasonCell.h"

@implementation BuyReasonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
