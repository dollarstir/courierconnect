//
//  ReasonToBuyCell.h
//  QuickClick
//
//  Created by Kaushal PC on 13/09/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReasonToBuyCell : UITableViewCell

@end
