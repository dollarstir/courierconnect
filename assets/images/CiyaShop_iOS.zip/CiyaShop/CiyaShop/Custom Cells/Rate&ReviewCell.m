//
//  Rate&ReviewCell.m
//  QuickClick
//
//  Created by Kaushal PC on 25/04/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "Rate&ReviewCell.h"

@implementation Rate_ReviewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
