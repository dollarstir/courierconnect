//
//  VariationItemCell.m
//  QuickClick
//
//  Created by Kaushal PC on 13/07/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "VariationItemCell.h"

@implementation VariationItemCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
