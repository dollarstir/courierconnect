//
//  HotOffersCell.h
//  QuickClick
//
//  Created by APPLE on 26/04/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotOffersCell : UICollectionViewCell

@property (weak,nonatomic) IBOutlet UIImageView *imgHotOffer;

@end
