//
//  SubSearchCell.m
//  QuickClick
//
//  Created by Kaushal PC on 12/05/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "SubSearchCell.h"

@implementation SubSearchCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
