//
//  SallerReviewCell.m
//  CiyaShop
//
//  Created by Kaushal PC on 14/11/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import "SallerReviewCell.h"

@implementation SallerReviewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
