//
//  MyPoints.h
//  CiyaShop
//
//  Created by potenza on 11/05/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyPoints : NSObject
@property (strong,nonatomic) NSString *strDescription;
@property (strong,nonatomic) NSString *strDate;
@property (strong,nonatomic) NSString *strPoints;
@end
