//
//  MyPoints.m
//  CiyaShop
//
//  Created by potenza on 11/05/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import "MyPoints.h"

@implementation MyPoints



@end
