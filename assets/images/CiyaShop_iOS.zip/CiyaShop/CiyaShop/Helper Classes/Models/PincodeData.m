//
//  PincodeData.m
//  CiyaShop
//
//  Created by Kaushal Parmar on 24/06/19.
//  Copyright © 2019 Potenza. All rights reserved.
//

#import "PincodeData.h"

@implementation PincodeData

@end
