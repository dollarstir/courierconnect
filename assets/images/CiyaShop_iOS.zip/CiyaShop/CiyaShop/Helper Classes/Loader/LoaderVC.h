//
//  LoaderVC.h
//  EverAfter
//
//  Created by potenza on 28/07/17.
//  Copyright © 2017 Potenza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoaderVC : UIViewController

@end
