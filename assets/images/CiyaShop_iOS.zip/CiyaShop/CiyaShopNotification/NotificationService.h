//
//  NotificationService.h
//  CiyaShopNotification
//
//  Created by Kaushal PC on 02/08/18.
//  Copyright © 2018 Potenza. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
