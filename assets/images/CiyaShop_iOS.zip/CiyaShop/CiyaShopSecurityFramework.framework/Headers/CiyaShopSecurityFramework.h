//
//  CiyaShopSecurityFramework.h
//  CiyaShopSecurityFramework
//
//  Created by Jitendra on 28/08/18.
//  Copyright © 2018 Jitendra. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CiyaShopSecurityFramework.
FOUNDATION_EXPORT double CiyaShopSecurityFrameworkVersionNumber;

//! Project version string for CiyaShopSecurityFramework.
FOUNDATION_EXPORT const unsigned char CiyaShopSecurityFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CiyaShopSecurityFramework/PublicHeader.h>

#import <CiyaShopSecurityFramework/CiyaShopAPISecurity.h>
